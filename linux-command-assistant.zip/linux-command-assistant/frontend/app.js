// LinuxAI chat page. Plain JavaScript, no build step.

const $ = (sel, el = document) => el.querySelector(sel);

const RISK = {
  safe: { label: "Read-only", cls: "safe" },
  caution: { label: "Changes things", cls: "caution" },
  dangerous: { label: "Dangerous", cls: "danger" },
  blocked: { label: "Blocked", cls: "blocked" },
};

// Saved settings live in the browser. Wrapped so a blocked storage never breaks the page.
const store = {
  get(key, fallback) {
    try { const v = localStorage.getItem("lca." + key); return v === null ? fallback : v; }
    catch { return fallback; }
  },
  set(key, value) {
    try { if (value === null) localStorage.removeItem("lca." + key); else localStorage.setItem("lca." + key, value); }
    catch { /* ignore */ }
  },
};

const state = {
  sessionId: store.get("session", null),
  mode: store.get("mode", "beginner"),
  distro: store.get("distro", "ubuntu"),
  busy: false,
};

const el = {
  messages: $("#messages"),
  empty: $("#empty"),
  input: $("#input"),
  send: $("#sendBtn"),
  composer: $("#composer"),
  sessions: $("#sessions"),
  status: $("#status"),
  title: $("#chatTitle"),
  sidebar: $("#sidebar"),
  scrim: $("#scrim"),
};

// ---------------------------------------------------------------- helpers

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// Tiny markdown: `code`, **bold**, line breaks. Everything is escaped first.
function md(s) {
  return esc(s)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\n/g, "<br>");
}

async function api(path, options = {}) {
  const res = await fetch(path, { headers: { "Content-Type": "application/json" }, ...options });
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    const detail = data && data.detail;
    throw new Error(typeof detail === "string" ? detail : `Request failed (${res.status}).`);
  }
  return data;
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  }
}

function scrollDown() {
  el.messages.scrollTop = el.messages.scrollHeight;
}

// ---------------------------------------------------------------- rendering

function showEmpty(show) {
  el.empty.hidden = !show;
}

function addUser(text) {
  showEmpty(false);
  const div = document.createElement("div");
  div.className = "msg user";
  div.innerHTML = `<div class="bubble">${esc(text)}</div>`;
  el.messages.appendChild(div);
  scrollDown();
}

function commandCard(cmd, index) {
  const risk = cmd.risk || { level: "caution", reasons: [] };
  const r = RISK[risk.level] || RISK.caution;
  const card = document.createElement("div");
  card.className = `cmd ${r.cls}`;

  const breakdown = (cmd.breakdown || [])
    .map((b) => `<tr><td>${esc(b.part)}</td><td>${md(b.meaning)}</td></tr>`)
    .join("");
  const reasons = (risk.reasons || []).map((x) => `<li>${md(x)}</li>`).join("");

  card.innerHTML = `
    <div class="cmd-head">
      <span class="tag">${index === 0 ? "Suggested" : "Alternative"}</span>
      <span class="badge ${r.cls}" title="Rated by the safety rules">${r.label}</span>
      <button class="copy" type="button">Copy</button>
    </div>
    <pre class="code"><span class="prompt">$ </span><span class="cmdtext">${esc(cmd.command)}</span></pre>
    <div class="cmd-body">
      ${cmd.explanation ? `<p class="expl">${md(cmd.explanation)}</p>` : ""}
      ${reasons ? `<ul class="reasons">${reasons}</ul>` : ""}
      ${breakdown ? `<details ${state.mode === "beginner" ? "open" : ""}><summary>How it works</summary><table class="breakdown">${breakdown}</table></details>` : ""}
    </div>`;

  const btn = $(".copy", card);
  if (risk.level === "blocked") {
    btn.disabled = true;
    btn.textContent = "Can't copy";
    btn.title = "This command could destroy your system, so copying is turned off.";
  } else {
    btn.addEventListener("click", async () => {
      // Dangerous commands need a second click so they aren't copied by accident.
      if (risk.level === "dangerous" && !btn.classList.contains("confirm")) {
        btn.classList.add("confirm");
        btn.textContent = "Copy anyway?";
        setTimeout(() => { btn.classList.remove("confirm"); if (btn.textContent === "Copy anyway?") btn.textContent = "Copy"; }, 4000);
        return;
      }
      btn.classList.remove("confirm");
      btn.textContent = (await copyText(cmd.command)) ? "Copied" : "Copy failed";
      setTimeout(() => (btn.textContent = "Copy"), 1500);
    });
  }
  return card;
}

function addAssistant(data) {
  showEmpty(false);
  const div = document.createElement("div");
  div.className = "msg assistant";
  if (data.reply) {
    const p = document.createElement("p");
    p.className = "reply";
    p.innerHTML = md(data.reply);
    div.appendChild(p);
  }
  (data.commands || []).forEach((c, i) => div.appendChild(commandCard(c, i)));
  if (data.notes) {
    const n = document.createElement("div");
    n.className = "notes";
    n.innerHTML = md(data.notes);
    div.appendChild(n);
  }
  el.messages.appendChild(div);
  scrollDown();
}

function addError(message) {
  const div = document.createElement("div");
  div.className = "msg error";
  div.innerHTML = `<p class="reply">${md(message)}</p>`;
  el.messages.appendChild(div);
  scrollDown();
}

function addTyping() {
  const div = document.createElement("div");
  div.className = "msg assistant";
  div.innerHTML = `<div class="typing" aria-label="Thinking"><span></span><span></span><span></span></div>`;
  el.messages.appendChild(div);
  scrollDown();
  return div;
}

function clearMessages() {
  el.messages.querySelectorAll(".msg").forEach((m) => m.remove());
  showEmpty(true);
}

// ---------------------------------------------------------------- chat

async function send(text) {
  text = text.trim();
  if (!text || state.busy) return;
  state.busy = true;
  el.send.disabled = true;
  el.input.value = "";
  autosize();
  addUser(text);
  const typing = addTyping();

  try {
    const data = await api("/api/chat", {
      method: "POST",
      body: JSON.stringify({ message: text, session_id: state.sessionId, mode: state.mode, distro: state.distro }),
    });
    typing.remove();
    const isNew = data.session_id !== state.sessionId;
    setSession(data.session_id);
    addAssistant(data);
    if (isNew) loadSessions();
  } catch (err) {
    typing.remove();
    addError(err.message);
  } finally {
    state.busy = false;
    el.send.disabled = false;
    el.input.focus();
  }
}

function setSession(id) {
  state.sessionId = id;
  store.set("session", id);
  document.querySelectorAll(".sessions li").forEach((li) => li.classList.toggle("active", li.dataset.id === id));
}

async function openSession(id) {
  closeSidebar();
  try {
    const data = await api(`/api/sessions/${encodeURIComponent(id)}`);
    clearMessages();
    setSession(id);
    data.messages.forEach((m) => (m.role === "user" ? addUser(m.content) : addAssistant(m)));
    const li = document.querySelector(`.sessions li[data-id="${CSS.escape(id)}"] .title`);
    el.title.textContent = li ? li.textContent : "Chat";
  } catch {
    setSession(null);
    clearMessages();
  }
}

function newChat() {
  setSession(null);
  clearMessages();
  el.title.textContent = "New chat";
  closeSidebar();
  el.input.focus();
}

async function loadSessions() {
  let list = [];
  try { list = await api("/api/sessions"); } catch { /* server not ready */ }
  el.sessions.innerHTML = "";
  if (!list.length) {
    el.sessions.innerHTML = `<li class="none">No chats yet</li>`;
    return;
  }
  list.forEach((s) => {
    const li = document.createElement("li");
    li.dataset.id = s.id;
    li.classList.toggle("active", s.id === state.sessionId);
    li.innerHTML = `<span class="title">${esc(s.title)}</span><button class="del" type="button" aria-label="Delete chat">✕</button>`;
    li.addEventListener("click", () => openSession(s.id));
    $(".del", li).addEventListener("click", async (e) => {
      e.stopPropagation();
      try { await api(`/api/sessions/${encodeURIComponent(s.id)}`, { method: "DELETE" }); } catch { /* ignore */ }
      if (s.id === state.sessionId) newChat();
      loadSessions();
    });
    el.sessions.appendChild(li);
  });
  const active = list.find((s) => s.id === state.sessionId);
  if (active) el.title.textContent = active.title;
}

// ---------------------------------------------------------------- safety check

$("#checkForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const command = $("#checkInput").value.trim();
  const box = $("#checkResult");
  if (!command) return;
  try {
    const data = await api("/api/validate", { method: "POST", body: JSON.stringify({ command }) });
    const r = RISK[data.level];
    const reasons = data.reasons.length
      ? `<ul>${data.reasons.map((x) => `<li>${md(x)}</li>`).join("")}</ul>`
      : `<div class="hint" style="margin-top:6px">Only reads information. Nothing is changed.</div>`;
    box.innerHTML = `<span class="badge ${r.cls}">${r.label}</span>${reasons}`;
  } catch (err) {
    box.innerHTML = `<span class="hint">${esc(err.message)}</span>`;
  }
  box.hidden = false;
});

// ---------------------------------------------------------------- settings & status

function applyMode() {
  document.querySelectorAll("#modeToggle button").forEach((b) => b.classList.toggle("active", b.dataset.mode === state.mode));
}
document.querySelectorAll("#modeToggle button").forEach((b) =>
  b.addEventListener("click", () => {
    state.mode = b.dataset.mode;
    store.set("mode", state.mode);
    applyMode();
  })
);

const distroSelect = $("#distro");
distroSelect.value = state.distro;
distroSelect.addEventListener("change", () => {
  state.distro = distroSelect.value;
  store.set("distro", state.distro);
});

async function checkHealth() {
  const text = $(".status-text", el.status);
  el.status.className = "status";
  try {
    const h = await api("/api/health");
    if (!h.ollama) {
      el.status.classList.add("bad");
      text.textContent = "Ollama is not running";
    } else if (!h.model_available) {
      el.status.classList.add("warn");
      text.textContent = `Run: ollama pull ${h.model}`;
    } else {
      el.status.classList.add("ok");
      text.textContent = `${h.model} ready`;
    }
  } catch {
    el.status.classList.add("bad");
    text.textContent = "Server not reachable";
  }
}

// ---------------------------------------------------------------- input & layout

function autosize() {
  el.input.style.height = "auto";
  el.input.style.height = Math.min(el.input.scrollHeight, 180) + "px";
}
el.input.addEventListener("input", autosize);
el.input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    send(el.input.value);
  }
});
el.composer.addEventListener("submit", (e) => {
  e.preventDefault();
  send(el.input.value);
});
document.querySelectorAll(".suggestions button").forEach((b) => b.addEventListener("click", () => send(b.textContent)));
$("#newChat").addEventListener("click", newChat);

function closeSidebar() {
  el.sidebar.classList.remove("open");
  el.scrim.classList.remove("show");
}
$("#menuBtn").addEventListener("click", () => {
  el.sidebar.classList.add("open");
  el.scrim.classList.add("show");
});
el.scrim.addEventListener("click", closeSidebar);

// ---------------------------------------------------------------- start

applyMode();
checkHealth();
setInterval(checkHealth, 15000);
loadSessions().then(() => {
  if (state.sessionId) openSession(state.sessionId);
});
el.input.focus();
