import json

import pytest
from fastapi.testclient import TestClient

from backend import config, llm


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "DB_PATH", str(tmp_path / "test.db"))
    from backend.main import app
    with TestClient(app) as c:
        yield c


def fake_model(answer: dict, seen: list | None = None):
    async def _chat(messages):
        if seen is not None:
            seen.append(messages)
        return json.dumps(answer)
    return _chat


def test_chat_returns_commands_with_risk(client, monkeypatch):
    monkeypatch.setattr(llm, "chat", fake_model({
        "reply": "Here you go.",
        "commands": [{"command": "rm -rf /", "explanation": "bad"},
                     {"command": "ls", "explanation": "lists"}],
    }))
    r = client.post("/api/chat", json={"message": "delete everything"})
    assert r.status_code == 200
    data = r.json()
    assert data["session_id"]
    # The validator overrides whatever the model says.
    assert data["commands"][0]["risk"]["level"] == "blocked"
    assert data["commands"][1]["risk"]["level"] == "safe"


def test_history_is_sent_back_for_follow_ups(client, monkeypatch):
    seen = []
    monkeypatch.setattr(llm, "chat", fake_model({"reply": "ok", "commands": ["find . -type f"]}, seen))
    sid = client.post("/api/chat", json={"message": "list all files"}).json()["session_id"]
    client.post("/api/chat", json={"message": "now only python files", "session_id": sid})
    second_call = seen[1]
    roles = [m["role"] for m in second_call]
    assert roles == ["system", "user", "assistant", "user"]
    assert "find . -type f" in second_call[2]["content"]


def test_sessions_list_load_and_delete(client, monkeypatch):
    monkeypatch.setattr(llm, "chat", fake_model({"reply": "ok", "commands": ["pwd"]}))
    sid = client.post("/api/chat", json={"message": "where am I"}).json()["session_id"]
    assert client.get("/api/sessions").json()[0]["id"] == sid
    msgs = client.get(f"/api/sessions/{sid}").json()["messages"]
    assert msgs[0] == {"role": "user", "content": "where am I"}
    assert msgs[1]["commands"][0]["command"] == "pwd"
    assert client.delete(f"/api/sessions/{sid}").status_code == 200
    assert client.get(f"/api/sessions/{sid}").status_code == 404


def test_model_down_gives_clear_error_and_no_empty_chat(client, monkeypatch):
    async def broken(_messages):
        raise llm.LLMError("Can't reach Ollama")
    monkeypatch.setattr(llm, "chat", broken)
    r = client.post("/api/chat", json={"message": "hi"})
    assert r.status_code == 503
    assert "Ollama" in r.json()["detail"]
    assert client.get("/api/sessions").json() == []


def test_validate_endpoint(client):
    r = client.post("/api/validate", json={"command": "mkfs.ext4 /dev/sdb"})
    assert r.json()["level"] == "blocked"


def test_rejects_bad_input(client):
    assert client.post("/api/chat", json={"message": ""}).status_code == 422
    assert client.post("/api/chat", json={"message": "hi", "mode": "wizard"}).status_code == 422


def test_serves_web_page(client):
    r = client.get("/")
    assert r.status_code == 200
    assert "LinuxAI" in r.text
