import sys
from pathlib import Path

# Let tests import the `backend` package when run from the project folder.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
