import json

from backend.llm import parse_response
from backend.prompts import build_system_prompt


def test_parses_clean_json():
    raw = json.dumps({
        "reply": "Use df.",
        "commands": [{"command": "df -h", "explanation": "Disk space.",
                      "breakdown": [{"part": "-h", "meaning": "human readable"}]}],
        "notes": "",
    })
    out = parse_response(raw)
    assert out["reply"] == "Use df."
    assert out["commands"][0]["command"] == "df -h"
    assert out["commands"][0]["breakdown"][0]["part"] == "-h"


def test_json_wrapped_in_text():
    raw = 'Sure! {"reply": "ok", "commands": ["pwd"]} hope that helps'
    out = parse_response(raw)
    assert out["commands"][0]["command"] == "pwd"


def test_plain_text_with_code_block():
    raw = "Run this:\n```bash\nls -la\n```\nIt lists files."
    out = parse_response(raw)
    assert out["commands"][0]["command"] == "ls -la"
    assert "Run this" in out["reply"]


def test_strips_prompt_sign_and_limits_to_three():
    raw = json.dumps({"reply": "x", "commands": ["$ ls", "pwd", "whoami", "date"]})
    out = parse_response(raw)
    assert [c["command"] for c in out["commands"]] == ["ls", "pwd", "whoami"]


def test_garbage_gives_friendly_reply():
    out = parse_response("")
    assert out["commands"] == []
    assert out["reply"]


def test_prompt_includes_mode_and_distro():
    p = build_system_prompt("expert", "arch")
    assert "experienced" in p and "pacman" in p
