"""Builds the conversation for the model and checks every command it returns."""
from __future__ import annotations

import json

from . import config, database, llm, validator
from .prompts import build_system_prompt


def _assistant_turn_as_text(stored: str) -> str:
    """Rebuild a short text version of an earlier answer to give the model context."""
    try:
        data = json.loads(stored)
    except ValueError:
        return stored
    lines = [data.get("reply", "")]
    for c in data.get("commands", []):
        lines.append(f"Command: {c.get('command', '')}")
    return "\n".join(line for line in lines if line)


def build_messages(history: list[dict], user_message: str, mode: str, distro: str) -> list[dict]:
    messages = [{"role": "system", "content": build_system_prompt(mode, distro)}]
    for m in history[-config.HISTORY_TURNS * 2:]:
        content = m["content"] if m["role"] == "user" else _assistant_turn_as_text(m["content"])
        messages.append({"role": m["role"], "content": content})
    messages.append({"role": "user", "content": user_message})
    return messages


def attach_risk(result: dict) -> dict:
    """Rate every command with the rule-based validator, ignoring what the model thinks."""
    for cmd in result["commands"]:
        cmd["risk"] = validator.assess(cmd["command"]).to_dict()
    return result


async def answer(session_id: str | None, user_message: str, mode: str, distro: str) -> dict:
    history = database.get_messages(session_id) if session_id else []
    messages = build_messages(history, user_message, mode, distro)
    raw = await llm.chat(messages)
    return attach_risk(llm.parse_response(raw))
