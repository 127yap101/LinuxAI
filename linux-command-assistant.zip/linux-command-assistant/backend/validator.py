"""Rule-based safety checker for shell commands.

This module never trusts the language model. Every command the model
suggests is parsed and rated here, and the final risk level shown to the
user comes from these rules.

Levels (lowest to highest):
    safe       only reads information, changes nothing
    caution    creates, changes or installs something
    dangerous  can delete data, stop the system, or affect everything
    blocked    almost certainly destroys the system or a disk
"""
from __future__ import annotations

import os
import re
import shlex
from dataclasses import dataclass, field

LEVELS = ["safe", "caution", "dangerous", "blocked"]


def higher(a: str, b: str) -> str:
    return a if LEVELS.index(a) >= LEVELS.index(b) else b


@dataclass
class Assessment:
    level: str = "safe"
    reasons: list[str] = field(default_factory=list)

    def bump(self, level: str, reason: str | None = None) -> None:
        self.level = higher(self.level, level)
        if reason and reason not in self.reasons:
            self.reasons.append(reason)

    def to_dict(self) -> dict:
        return {"level": self.level, "reasons": list(self.reasons)}


# ---------------------------------------------------------------- word lists

READ_ONLY = {
    "ls", "pwd", "cd", "cat", "less", "more", "head", "tail", "grep", "egrep",
    "fgrep", "rg", "find", "locate", "which", "whereis", "type", "file", "stat",
    "wc", "sort", "uniq", "cut", "tr", "awk", "column", "diff", "cmp", "comm",
    "echo", "printf", "date", "cal", "uptime", "whoami", "id", "groups", "who",
    "w", "last", "uname", "hostname", "hostnamectl", "df", "du", "free", "ps",
    "top", "htop", "pgrep", "lsof", "lsblk", "blkid", "lscpu", "lsusb", "lspci",
    "env", "printenv", "history", "man", "info", "help", "tldr", "tree",
    "basename", "dirname", "realpath", "readlink", "md5sum", "sha256sum",
    "sha1sum", "base64", "xxd", "hexdump", "od", "strings", "nl", "tac", "rev",
    "seq", "yes", "true", "false", "test", "[", "sleep", "watch", "ping",
    "traceroute", "dig", "nslookup", "host", "ip", "ifconfig", "ss", "netstat",
    "journalctl", "dmesg", "vmstat", "iostat", "nproc", "arch", "jq", "tee",
    "xargs", "time", "nice", "nohup", "timeout", "clear", "alias", "export",
    "getent", "id", "curl", "wget", "zcat", "zgrep", "sed", "dpkg", "rpm",
}

CREATES_OR_CHANGES = {
    "mkdir": "Creates a folder.",
    "touch": "Creates an empty file or updates its timestamp.",
    "ln": "Creates a link to a file.",
    "tar": "Packs or unpacks archives; unpacking can overwrite files.",
    "zip": "Creates or changes a zip archive.",
    "unzip": "Unpacks files and may overwrite existing ones.",
    "gzip": "Compresses a file and replaces the original.",
    "gunzip": "Decompresses a file and replaces the original.",
    "nano": "Opens a file for editing.",
    "vim": "Opens a file for editing.",
    "vi": "Opens a file for editing.",
    "code": "Opens a file for editing.",
    "chgrp": "Changes which group owns a file.",
    "rsync": "Copies files and can overwrite or delete at the destination.",
    "scp": "Copies files to or from another machine.",
    "ssh": "Connects to another machine.",
    "git": "Changes the git repository.",
    "make": "Builds a project and may run arbitrary steps.",
    "python": "Runs a Python program.",
    "python3": "Runs a Python program.",
    "node": "Runs a JavaScript program.",
    "bash": "Runs a shell script; check what it does first.",
    "sh": "Runs a shell script; check what it does first.",
    "zsh": "Runs a shell script; check what it does first.",
    "source": "Runs a script inside your current shell.",
    ".": "Runs a script inside your current shell.",
    "eval": "Runs text as a command; check it carefully.",
    "crontab": "Changes scheduled tasks.",
    "docker": "Manages containers.",
    "useradd": "Creates a user account.",
    "adduser": "Creates a user account.",
    "usermod": "Changes a user account.",
    "passwd": "Changes a password.",
    "kill": "Stops a running program.",
    "pkill": "Stops running programs that match a name.",
    "killall": "Stops all programs with this name.",
    "export": "Sets an environment variable for this shell.",
}

ALWAYS_DANGEROUS = {
    "shred": "Overwrites a file so it can never be recovered.",
    "wipefs": "Erases filesystem signatures from a disk.",
    "fdisk": "Edits disk partitions; a mistake can lose all data.",
    "parted": "Edits disk partitions; a mistake can lose all data.",
    "gdisk": "Edits disk partitions; a mistake can lose all data.",
    "mkswap": "Turns a partition into swap space, erasing it.",
    "truncate": "Cuts a file down in size and loses its contents.",
    "userdel": "Deletes a user account.",
    "deluser": "Deletes a user account.",
    "groupdel": "Deletes a group.",
    "visudo": "Edits who can use sudo; a mistake can lock you out.",
    "iptables": "Changes firewall rules; a mistake can cut network access.",
    "nft": "Changes firewall rules; a mistake can cut network access.",
    "ufw": "Changes firewall rules; a mistake can cut network access.",
    "mount": "Attaches a disk or filesystem.",
    "umount": "Detaches a disk or filesystem.",
    "swapoff": "Turns off swap memory.",
    "chattr": "Changes low-level file attributes.",
    "setfacl": "Changes file access rules.",
}

POWER = {"shutdown", "reboot", "halt", "poweroff", "init", "telinit"}

PACKAGE_MANAGERS = {
    "apt", "apt-get", "dnf", "yum", "pacman", "zypper", "snap", "flatpak",
    "pip", "pip3", "npm", "yarn", "pnpm", "brew", "dpkg", "rpm",
}
PKG_REMOVE = {"remove", "purge", "autoremove", "uninstall", "erase", "-r", "-R",
              "-Rs", "-Rns", "--purge", "-e"}
PKG_INSTALL = {"install", "upgrade", "update", "dist-upgrade", "full-upgrade",
               "-S", "-Syu", "-Sy", "-U", "add", "i", "-i", "reinstall"}

# Places that should never be deleted or opened up recursively.
CRITICAL_PATHS = {
    "/", "/*", "~", "~/", "~/*", "$HOME", "${HOME}", "$HOME/", "$HOME/*",
    "*", ".", "./", "./*", "..", "../", "/home", "/root", "/etc", "/usr",
    "/bin", "/sbin", "/lib", "/lib64", "/boot", "/var", "/opt", "/dev",
    "/sys", "/proc", "/srv", "/home/*",
}
SYSTEM_PREFIXES = ("/etc", "/usr", "/bin", "/sbin", "/lib", "/boot", "/sys",
                   "/proc", "/dev", "/var/lib", "/root")

SEPARATORS = {"|", "||", "&&", ";", "&", "|&", ";;", "\n"}
OUT_REDIRECTS = {">", ">>", ">|", "&>", "&>>"}
IN_REDIRECTS = {"<", "<<", "<<<"}

DISK_RE = r"/dev/(sd[a-z]|nvme\d|hd[a-z]|vd[a-z]|xvd[a-z]|mmcblk\d)"

RAW_PATTERNS: list[tuple[str, str, str]] = [
    (r":\s*\(\s*\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:", "blocked",
     "This is a fork bomb: it starts processes until the system freezes."),
    (r"\bmkfs(\.\w+)?\b", "blocked",
     "Formats a disk or partition and erases everything on it."),
    (r"\bdd\b.*\bof=" + DISK_RE, "blocked",
     "Writes directly over a disk and destroys its data."),
    (r">\s*" + DISK_RE, "blocked",
     "Writes directly over a disk and destroys its data."),
    (r"\b(curl|wget)\b[^|]*\|\s*(sudo\s+)?(ba|z|k|da)?sh\b", "dangerous",
     "Downloads a script from the internet and runs it without you reading it."),
    (r"--no-preserve-root", "blocked",
     "Turns off the protection that stops you from deleting the whole system."),
]


# ---------------------------------------------------------------- helpers

def _tokenize(command: str) -> list[str]:
    lex = shlex.shlex(command, posix=True, punctuation_chars=True)
    lex.whitespace_split = True
    lex.commenters = ""
    return list(lex)


def _split_segments(tokens: list[str], result: Assessment) -> list[list[str]]:
    segments: list[list[str]] = [[]]
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if tok in SEPARATORS:
            segments.append([])
        elif tok in OUT_REDIRECTS:
            target = tokens[i + 1] if i + 1 < len(tokens) else ""
            _check_redirect(tok, target, result)
            i += 1
        elif tok in IN_REDIRECTS or tok in {">&", "<&"}:
            i += 1  # skip the target / file descriptor
        elif tok in {"(", ")", "{", "}"}:
            pass
        else:
            segments[-1].append(tok)
        i += 1
    return [s for s in segments if s]


def _check_redirect(op: str, target: str, result: Assessment) -> None:
    if not target or target.startswith("/dev/null") or target in {"/dev/stdout", "/dev/stderr"}:
        return
    if re.match(DISK_RE, target):
        result.bump("blocked", "Writes directly over a disk and destroys its data.")
    elif target.startswith(SYSTEM_PREFIXES):
        result.bump("dangerous", f"Writes into the system file {target}.")
    elif op in {">>", "&>>"}:
        result.bump("caution", f"Adds text to the end of {target}.")
    else:
        result.bump("caution", f"Replaces the contents of {target} if it already exists.")


def _short_flags(words: list[str]) -> set[str]:
    """Collect single-letter flags, so `-rf` gives {'r', 'f'}."""
    letters: set[str] = set()
    for w in words:
        if w.startswith("-") and not w.startswith("--") and len(w) > 1:
            letters.update(w[1:])
    return letters


def _targets(words: list[str]) -> list[str]:
    return [w for w in words if not w.startswith("-")]


def _is_critical(path: str) -> bool:
    p = path.rstrip("/") or "/"
    return path in CRITICAL_PATHS or p in CRITICAL_PATHS


# ---------------------------------------------------------------- per command

def _check_segment(words: list[str], result: Assessment) -> None:
    # Skip leading VAR=value assignments.
    while words and re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", words[0]):
        words = words[1:]
    if not words:
        return

    elevated = False
    # Unwrap helpers that run another command.
    while words:
        name = os.path.basename(words[0])
        if name in {"sudo", "doas", "su"}:
            elevated = True
            result.bump("caution", "Runs with administrator (root) rights, so it asks for your password.")
            words = words[1:]
            while words and words[0].startswith("-"):
                words = words[1:]
        elif name in {"nohup", "time", "nice", "timeout", "env", "command", "exec", "watch"}:
            words = words[1:]
            while words and (words[0].startswith("-") or re.match(r"^\d+[smhd]?$", words[0])
                             or "=" in words[0]):
                words = words[1:]
        elif name == "xargs":
            words = words[1:]
            while words and words[0].startswith("-"):
                words = words[1:]
        else:
            break
    if not words:
        return

    cmd = os.path.basename(words[0])
    args = words[1:]
    flags = _short_flags(args)
    before = result.level
    local = Assessment()

    if cmd == "rm":
        recursive = bool({"r", "R"} & flags) or "--recursive" in args
        local.bump("dangerous", "Deletes files permanently (there is no recycle bin).")
        if recursive:
            local.bump("dangerous", "Deletes folders and everything inside them.")
        for t in _targets(args):
            if _is_critical(t):
                local.bump("blocked" if recursive or t in {"/", "/*"} else "dangerous",
                           f"Deleting {t} would wipe out the system or your files.")
            elif t.startswith(SYSTEM_PREFIXES):
                local.bump("blocked" if recursive else "dangerous",
                           f"Deletes system files under {t}.")
    elif cmd == "rmdir":
        local.bump("caution", "Removes an empty folder.")
    elif cmd in {"mv", "cp"}:
        if "i" in flags or "n" in flags or "--interactive" in args or "--no-clobber" in args:
            local.bump("caution", "Copies or moves files (asks before overwriting).")
        else:
            local.bump("caution", "Can overwrite existing files without asking.")
        for t in _targets(args):
            if t.startswith(SYSTEM_PREFIXES):
                local.bump("dangerous", f"Changes system files under {t}.")
        if cmd == "mv" and any(_is_critical(t) and t not in {".", "./"} for t in _targets(args)[:-1]):
            local.bump("blocked", "Moves a critical system folder.")
    elif cmd in {"chmod", "chown"}:
        recursive = "R" in flags or "--recursive" in args
        what = "permissions" if cmd == "chmod" else "owner"
        local.bump("caution", f"Changes file {what}.")
        targets = _targets(args)[1:] if cmd == "chmod" else _targets(args)[1:]
        mode = _targets(args)[0] if _targets(args) else ""
        if cmd == "chmod" and re.fullmatch(r"0?777|a\+rwx|ugo\+rwx", mode):
            local.bump("dangerous", "Lets every user read, change and run the file (777).")
        for t in targets:
            if _is_critical(t) and recursive:
                local.bump("blocked", f"Recursively changing {what} on {t} can break the whole system.")
            elif t.startswith(SYSTEM_PREFIXES):
                local.bump("dangerous", f"Changes {what} of system files under {t}.")
    elif cmd == "dd":
        local.bump("dangerous", "Low-level copy: a wrong `of=` target overwrites a disk.")
    elif cmd in POWER:
        local.bump("dangerous", "Shuts down or restarts the computer.")
    elif cmd == "systemctl":
        sub = _targets(args)[0] if _targets(args) else ""
        if sub in {"stop", "disable", "mask", "kill", "poweroff", "reboot", "halt", "isolate"}:
            local.bump("dangerous", f"`systemctl {sub}` stops or disables a system service.")
        elif sub in {"start", "restart", "enable", "reload", "daemon-reload", "edit"}:
            local.bump("caution", f"`systemctl {sub}` changes a running system service.")
    elif cmd == "service":
        if any(a in {"stop", "restart"} for a in args):
            local.bump("caution", "Stops or restarts a system service.")
    elif cmd in PACKAGE_MANAGERS:
        if any(a in PKG_REMOVE for a in args):
            local.bump("dangerous", "Uninstalls software, which may also remove things that depend on it.")
        elif any(a in PKG_INSTALL for a in args):
            local.bump("caution", "Installs or updates software.")
    elif cmd == "find":
        if "-delete" in args:
            local.bump("dangerous", "`-delete` removes every file that matches.")
        for flag in ("-exec", "-execdir", "-ok", "-okdir"):
            if flag in args:
                idx = args.index(flag)
                inner = args[idx + 1:]
                if inner and inner[-1] in {";", "+", "\\;"}:
                    inner = inner[:-1]
                if inner:
                    sub = Assessment()
                    _check_segment(inner, sub)
                    local.bump(higher("caution", sub.level),
                               "Runs another command on every file it finds.")
                    for r in sub.reasons:
                        local.bump(sub.level, r)
    elif cmd == "sed":
        if "i" in flags or any(a.startswith("--in-place") for a in args):
            local.bump("caution", "Edits files in place (the original text is replaced).")
    elif cmd == "kill":
        local.bump("caution", "Stops a running program.")
        if "-1" in args and ("-9" in args or "-KILL" in args or "-SIGKILL" in args):
            local.bump("dangerous", "`kill -9 -1` stops every program you are running.")
    elif cmd == "crontab":
        if "r" in flags:
            local.bump("dangerous", "`crontab -r` deletes all your scheduled tasks without asking.")
        elif "e" in flags or _targets(args):
            local.bump("caution", "Changes scheduled tasks.")
    elif cmd == "git":
        sub = _targets(args)[0] if _targets(args) else ""
        if sub in {"status", "log", "diff", "show", "remote", "blame", "grep", "ls-files", "rev-parse", "describe"}:
            pass
        elif (sub == "reset" and "--hard" in args) or (sub == "clean" and "f" in flags) \
                or (sub == "push" and ("f" in flags or "--force" in args)) \
                or (sub == "branch" and "D" in flags) \
                or (sub == "checkout" and "." in args):
            local.bump("dangerous", "This git command throws away work that may not be recoverable.")
        else:
            local.bump("caution", "Changes the git repository.")
    elif cmd in ALWAYS_DANGEROUS:
        local.bump("dangerous", ALWAYS_DANGEROUS[cmd])
    elif cmd in CREATES_OR_CHANGES:
        local.bump("caution", CREATES_OR_CHANGES[cmd])
    elif cmd in READ_ONLY:
        pass
    elif result.level != "blocked":  # already blocked by a raw pattern; no need to add noise
        local.bump("caution", f"`{cmd}` is not in the assistant's list of known commands. Check it before running.")

    if elevated and local.level != "safe":
        local.bump(local.level, "Because of sudo, a mistake here affects the whole system.")

    for r in local.reasons:
        result.bump(local.level, r)
    result.level = higher(result.level, higher(before, local.level))


# ---------------------------------------------------------------- public API

def assess(command: str) -> Assessment:
    """Rate how risky a shell command is. Never runs the command."""
    result = Assessment()
    command = (command or "").strip()
    if not command:
        return result

    for pattern, level, reason in RAW_PATTERNS:
        if re.search(pattern, command):
            result.bump(level, reason)

    if "$(" in command or "`" in command:
        result.bump("caution", "Contains a command inside `$( )` or backticks, which runs first.")

    try:
        tokens = _tokenize(command)
    except ValueError:
        result.bump("caution", "Could not fully read this command (unbalanced quotes).")
        tokens = command.split()

    for segment in _split_segments(tokens, result):
        _check_segment(segment, result)

    return result
