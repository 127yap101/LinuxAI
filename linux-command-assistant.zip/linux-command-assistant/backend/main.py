"""FastAPI app: the chat API plus the web page.

Run from the project folder:
    uvicorn backend.main:app --reload
then open http://localhost:8000
"""
from __future__ import annotations

import json
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import assistant, config, database, llm, validator


@asynccontextmanager
async def lifespan(_app: FastAPI):
    database.init_db()
    yield


app = FastAPI(title="Linux Command Assistant", version="1.0.0", lifespan=lifespan)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    session_id: str | None = None
    mode: Literal["beginner", "expert"] = "beginner"
    distro: Literal["ubuntu", "fedora", "arch"] = "ubuntu"


class ValidateRequest(BaseModel):
    command: str = Field(min_length=1, max_length=2000)


@app.post("/api/chat")
async def chat(req: ChatRequest):
    message = req.message.strip()
    if not message:
        raise HTTPException(422, "Message is empty.")

    sid = req.session_id if req.session_id and database.session_exists(req.session_id) else None
    try:
        result = await assistant.answer(sid, message, req.mode, req.distro)
    except llm.LLMError as exc:
        raise HTTPException(503, str(exc))

    # Only save once the model has answered, so failed requests leave no empty chats.
    if sid is None:
        sid = database.create_session(message)
    database.add_message(sid, "user", message)
    database.add_message(sid, "assistant", json.dumps(result))
    return {"session_id": sid, **result}


@app.post("/api/validate")
async def validate(req: ValidateRequest):
    """Rate a command with the safety rules only. The model is not involved."""
    return {"command": req.command, **validator.assess(req.command).to_dict()}


@app.get("/api/sessions")
async def sessions():
    return database.list_sessions()


@app.get("/api/sessions/{sid}")
async def session_messages(sid: str):
    if not database.session_exists(sid):
        raise HTTPException(404, "Chat not found.")
    out = []
    for m in database.get_messages(sid):
        if m["role"] == "assistant":
            try:
                out.append({"role": "assistant", **json.loads(m["content"])})
            except ValueError:
                out.append({"role": "assistant", "reply": m["content"], "commands": [], "notes": ""})
        else:
            out.append({"role": "user", "content": m["content"]})
    return {"session_id": sid, "messages": out}


@app.delete("/api/sessions/{sid}")
async def delete_session(sid: str):
    if not database.delete_session(sid):
        raise HTTPException(404, "Chat not found.")
    return {"deleted": sid}


@app.get("/api/health")
async def health():
    return await llm.health()


# The web page. Mounted last so it doesn't hide the /api routes.
app.mount("/", StaticFiles(directory=config.FRONTEND_DIR, html=True), name="frontend")
