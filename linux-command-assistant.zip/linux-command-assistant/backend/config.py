"""Settings, read from environment variables so nothing is hard-coded."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Where Ollama is running and which model to use.
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5-coder:7b")

# Seconds to wait for the model before giving up.
REQUEST_TIMEOUT = float(os.getenv("LCA_TIMEOUT", "120"))

# How many past user/assistant turns to send back to the model as context.
HISTORY_TURNS = int(os.getenv("LCA_HISTORY_TURNS", "6"))

# SQLite file for chat history.
DB_PATH = os.getenv("LCA_DB_PATH", str(ROOT / "data" / "history.db"))

FRONTEND_DIR = ROOT / "frontend"
