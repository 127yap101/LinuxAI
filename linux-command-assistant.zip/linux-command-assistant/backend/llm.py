"""Talks to a local model through Ollama and turns its answer into clean data."""
from __future__ import annotations

import json
import re

import httpx

from . import config


class LLMError(Exception):
    """A problem reaching or using the model, with a message fit for the user."""


async def chat(messages: list[dict]) -> str:
    """Send the conversation to Ollama and return the raw text it answers with."""
    payload = {
        "model": config.OLLAMA_MODEL,
        "messages": messages,
        "stream": False,
        "format": "json",
        "options": {"temperature": 0.2},
    }
    try:
        async with httpx.AsyncClient(timeout=config.REQUEST_TIMEOUT) as client:
            resp = await client.post(f"{config.OLLAMA_URL}/api/chat", json=payload)
    except httpx.ConnectError:
        raise LLMError(
            f"Can't reach Ollama at {config.OLLAMA_URL}. Make sure it is running (`ollama serve`)."
        )
    except httpx.TimeoutException:
        raise LLMError("The model took too long to answer. Try again or use a smaller model.")

    if resp.status_code == 404:
        raise LLMError(
            f"Model '{config.OLLAMA_MODEL}' is not installed. Run: ollama pull {config.OLLAMA_MODEL}"
        )
    if resp.status_code >= 400:
        raise LLMError(f"Ollama returned an error ({resp.status_code}): {resp.text[:200]}")

    try:
        return resp.json()["message"]["content"]
    except (ValueError, KeyError, TypeError):
        raise LLMError("Ollama sent back a response the assistant could not read.")


async def health() -> dict:
    """Check whether Ollama is up and the chosen model is downloaded."""
    info = {"ollama": False, "model": config.OLLAMA_MODEL, "model_available": False}
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            resp = await client.get(f"{config.OLLAMA_URL}/api/tags")
        resp.raise_for_status()
    except (httpx.HTTPError, ValueError):
        return info
    info["ollama"] = True
    wanted = config.OLLAMA_MODEL if ":" in config.OLLAMA_MODEL else config.OLLAMA_MODEL + ":latest"
    names = {m.get("name", "") for m in resp.json().get("models", [])}
    info["model_available"] = wanted in names or config.OLLAMA_MODEL in names
    return info


# ------------------------------------------------------------ parsing

def _load_json(text: str):
    try:
        return json.loads(text)
    except (ValueError, TypeError):
        pass
    match = re.search(r"\{.*\}", text or "", re.S)
    if match:
        try:
            return json.loads(match.group(0))
        except ValueError:
            pass
    return None


def parse_response(text: str) -> dict:
    """Turn the model's answer into {reply, commands, notes}.

    Small local models do not always follow the JSON format, so this also
    accepts plain text and pulls commands out of ``` code blocks.
    """
    data = _load_json(text)
    if not isinstance(data, dict):
        blocks = re.findall(r"```(?:bash|sh|shell|console)?\s*\n(.*?)```", text or "", re.S)
        reply = re.sub(r"```.*?```", "", text or "", flags=re.S).strip()
        data = {"reply": reply, "commands": [{"command": b} for b in blocks]}
    return normalise(data)


def normalise(data: dict) -> dict:
    raw_cmds = data.get("commands") or []
    if isinstance(raw_cmds, (dict, str)):
        raw_cmds = [raw_cmds]

    commands = []
    for item in raw_cmds:
        if isinstance(item, str):
            item = {"command": item}
        if not isinstance(item, dict):
            continue
        command = str(item.get("command") or "").strip()
        command = re.sub(r"^\$\s+", "", command)  # drop a leading "$ " prompt
        if not command:
            continue
        breakdown = []
        for part in item.get("breakdown") or []:
            if isinstance(part, dict) and str(part.get("part") or "").strip():
                breakdown.append({
                    "part": str(part["part"]).strip(),
                    "meaning": str(part.get("meaning") or "").strip(),
                })
        commands.append({
            "command": command,
            "explanation": str(item.get("explanation") or "").strip(),
            "breakdown": breakdown,
        })

    reply = str(data.get("reply") or "").strip()
    if not reply and not commands:
        reply = "Sorry, I couldn't come up with an answer. Could you rephrase that?"
    return {
        "reply": reply,
        "commands": commands[:3],
        "notes": str(data.get("notes") or "").strip(),
    }
