# LinuxAI: Linux Command Assistant

A chatbot that turns plain English into Linux commands, explains every part of them, helps with terminal errors, and rates how risky each command is. It runs fully on your own machine with a local model through [Ollama](https://ollama.com). It never runs commands for you.

## What it does

- **English to command.** "Show the 10 largest files here" gives you the command, an explanation, and up to two alternatives.
- **Explains commands.** Ask "what does `chmod 755` do?" and get a part-by-part breakdown.
- **Troubleshoots errors.** Paste an error like `Permission denied` and get the likely cause and a fix.
- **Remembers the conversation.** Follow-ups like "now only the Python files" build on the last answer.
- **Safety rating on every command.** A rule-based checker (not the AI) rates each command as *Read-only*, *Changes things*, *Dangerous* or *Blocked*, and lists the reasons. Dangerous commands need a second click to copy. Blocked ones can't be copied at all.
- **Safety check box.** Paste any command into the sidebar to rate it instantly, without the AI.
- **Beginner / Expert mode** and **Ubuntu / Fedora / Arch** package commands.
- **Chat history** saved in SQLite.

## Setup

You need Python 3.10+ and Ollama. On Windows, use WSL2 with Ubuntu.

```bash
# 1. Install Ollama (Linux / WSL)
curl -fsSL https://ollama.com/install.sh | sh

# 2. Download a model (about 4.7 GB)
ollama pull qwen2.5-coder:7b

# 3. Install Python packages
cd linux-command-assistant
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# 4. Start the app
uvicorn backend.main:app --reload
```

Open http://localhost:8000. The dot at the bottom of the sidebar turns green when the model is ready.

> The Ollama install line above pipes a script into `sh`. That's the official method, but it's exactly the kind of thing the assistant's safety checker flags as dangerous. Read the script first if you want to be careful.

### Using a different model

Smaller machines can use a smaller model:

```bash
ollama pull llama3.2:3b
OLLAMA_MODEL=llama3.2:3b uvicorn backend.main:app --reload
```

| Variable | Default | Meaning |
| --- | --- | --- |
| `OLLAMA_MODEL` | `qwen2.5-coder:7b` | Which Ollama model to use |
| `OLLAMA_URL` | `http://localhost:11434` | Where Ollama is running |
| `LCA_TIMEOUT` | `120` | Seconds to wait for the model |
| `LCA_HISTORY_TURNS` | `6` | Past turns sent back as context |
| `LCA_DB_PATH` | `data/history.db` | Chat history file |

## Running the tests

```bash
python -m pytest -q
```

61 tests cover the safety rules, the parsing of model output, and the API (with a fake model, so Ollama isn't needed).

## How it works

```
Browser (frontend/)            FastAPI (backend/)                 Ollama
-------------------            ------------------                 ------
chat page  ── POST /api/chat ──▶ assistant.py
                                  ├─ adds system prompt + history
                                  ├─ llm.py ───────────────────────▶ local model
                                  │    turns reply into clean JSON ◀─
                                  ├─ validator.py rates each command
                                  └─ database.py saves the chat
           ◀── reply + commands + risk ──
```

The key design choice: **the model never decides what is safe.** `validator.py` parses each suggested command (pipes, `&&`, redirects, `sudo`, `find -exec`, and so on) and rates it using fixed rules. Its rating always wins.

### Project layout

```
backend/
  main.py        API routes and serves the web page
  assistant.py   builds the conversation, attaches risk ratings
  llm.py         Ollama client and output parsing
  prompts.py     system prompt, beginner/expert, distro hints
  validator.py   rule-based safety checker
  database.py    SQLite chat history
  config.py      settings from environment variables
frontend/
  index.html, style.css, app.js   the chat page (no build step)
tests/
  test_validator.py, test_parsing.py, test_api.py
```

### API

| Endpoint | Method | What it does |
| --- | --- | --- |
| `/api/chat` | POST | `{message, session_id?, mode, distro}` returns reply, commands with risk, notes |
| `/api/validate` | POST | `{command}` returns risk level and reasons (no AI) |
| `/api/sessions` | GET | List saved chats |
| `/api/sessions/{id}` | GET | Messages in one chat |
| `/api/sessions/{id}` | DELETE | Delete a chat |
| `/api/health` | GET | Is Ollama up, is the model downloaded |

Interactive API docs are at http://localhost:8000/docs.

## Limitations

- Local models can still suggest wrong commands or flags. Always read before running.
- The safety checker is rule-based. It catches common dangerous patterns but can't understand every possible shell trick, so treat it as a strong warning, not a guarantee.
- Flags differ slightly between distributions and tool versions (GNU vs BusyBox, for example).
